--
-- PostgreSQL database dump
--

\restrict wQDdFxaJSFqBTVNMC5A4Rw2subWhruzLa1j5oY63qWyTosCn6jyujU2LQqz09MV

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.11 (Ubuntu 17.11-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: je_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."je_admin"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
	SELECT EXISTS (
		SELECT 1 FROM "public"."profiles"
		WHERE "id" = (SELECT auth.uid()) AND "aktivan" AND "uloga" = 'admin'
	);
$$;


--
-- Name: FUNCTION "je_admin"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."je_admin"() IS 'Da li je prijavljeni nalog aktivan administrator.';


--
-- Name: je_clan(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."je_clan"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
	SELECT EXISTS (
		SELECT 1 FROM "public"."profiles"
		WHERE "id" = (SELECT auth.uid()) AND "aktivan"
	);
$$;


--
-- Name: FUNCTION "je_clan"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."je_clan"() IS 'Da li prijavljeni nalog ima aktivan red u profiles.';


--
-- Name: moj_tim(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."moj_tim"() RETURNS "uuid"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public', 'pg_temp'
    AS $$
	SELECT "tim_id" FROM "public"."profiles"
	WHERE "id" = (SELECT auth.uid()) AND "aktivan";
$$;


--
-- Name: FUNCTION "moj_tim"(); Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON FUNCTION "public"."moj_tim"() IS 'Tim prijavljenog naloga. NULL za administratora.';


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: destinacije; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."destinacije" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "drzava" "text" NOT NULL,
    "drzava_sifra" "text" NOT NULL,
    "regija" "text" NOT NULL,
    "grad" "text" NOT NULL,
    "aktivna" boolean DEFAULT true NOT NULL,
    "redosled" integer DEFAULT 0 NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."profiles" (
    "id" "uuid" NOT NULL,
    "ime" "text" NOT NULL,
    "email" "text" NOT NULL,
    "boja" "text" NOT NULL,
    "uloga" "text" DEFAULT 'korisnik'::"text" NOT NULL,
    "tim_id" "uuid",
    "aktivan" boolean DEFAULT true NOT NULL,
    CONSTRAINT "profiles_tim_prema_ulozi" CHECK (((("uloga" = 'admin'::"text") AND ("tim_id" IS NULL)) OR (("uloga" = 'korisnik'::"text") AND ("tim_id" IS NOT NULL)))),
    CONSTRAINT "profiles_uloga_dozvoljena" CHECK (("uloga" = ANY (ARRAY['admin'::"text", 'korisnik'::"text"])))
);


--
-- Name: COLUMN "profiles"."uloga"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."profiles"."uloga" IS 'admin ili korisnik.';


--
-- Name: COLUMN "profiles"."tim_id"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."profiles"."tim_id" IS 'Tim vozaca. NULL samo za administratore.';


--
-- Name: COLUMN "profiles"."aktivan"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."profiles"."aktivan" IS 'false zakljucava nalog pri sledecem zahtevu.';


--
-- Name: reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."reservations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "ime" "text" NOT NULL,
    "telefon" "text" NOT NULL,
    "destinacija_id" "uuid" NOT NULL,
    "datum_polaska" "date" NOT NULL,
    "destinacija_povratka_id" "uuid" NOT NULL,
    "datum_povratka" "date",
    "broj_putnika" integer NOT NULL,
    "kreirao" "uuid" NOT NULL,
    "tim_id" "uuid",
    CONSTRAINT "reservations_broj_putnika_pozitivan" CHECK (("broj_putnika" > 0)),
    CONSTRAINT "reservations_povratak_posle_polaska" CHECK ((("datum_povratka" IS NULL) OR ("datum_povratka" >= "datum_polaska")))
);


--
-- Name: COLUMN "reservations"."tim_id"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN "public"."reservations"."tim_id" IS 'Tim koji vidi rezervaciju. NULL znaci: vide je samo administratori.';


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."settings" (
    "id" integer DEFAULT 1 NOT NULL,
    "podrazumevana_destinacija_id" "uuid" NOT NULL,
    CONSTRAINT "settings_jedan_red" CHECK (("id" = 1))
);


--
-- Name: timovi; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."timovi" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "naziv" "text" NOT NULL
);


--
-- Name: TABLE "timovi"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE "public"."timovi" IS 'Jedinica vidljivosti. Clanovi jednog tima vide rezervacije svog tima.';


--
-- Data for Name: destinacije; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."destinacije" ("id", "drzava", "drzava_sifra", "regija", "grad", "aktivna", "redosled") FROM stdin;
de97c014-4065-4e50-9599-f198f979d2cb	Srbija	srbija	Beograd	Beograd	t	0
c99e0e87-e42d-4d2c-99fb-f010ba5f4bb9	Srbija	srbija	Kopaonik	Kopaonik	t	1
8d1e8dc7-720d-4dc0-b74f-fe4330f49f61	Grčka	grcka	Solun i okolina	Solun	t	0
9749d9b7-466c-4f44-a5ee-3b5fbb86d15f	Grčka	grcka	Solun i okolina	Perea	t	1
759f31dc-5772-4206-bcb6-92b55f56e031	Grčka	grcka	Solun i okolina	Nea Kalikratija	t	2
c1cd7cc7-f851-47ce-9ec0-1a138c2d8892	Grčka	grcka	Solun i okolina	Nea Mudanja	t	3
e78c7f33-0f6b-4359-b46e-f9c92c81dc3e	Grčka	grcka	Sitonija	Sarti	t	4
cab5f6e5-cf31-40db-a1b0-ed626c580bef	Grčka	grcka	Sitonija	Neos Marmaras	t	5
eac12b0e-b30d-4eec-9213-ac25fe5fe234	Grčka	grcka	Sitonija	Nikiti	t	6
c1f43945-052f-48a3-9852-399a07456f46	Grčka	grcka	Sitonija	Vurvuru	t	7
0f931bbb-4b8e-4923-8bc0-2b6bd76b30f9	Grčka	grcka	Sitonija	Toroni	t	8
231697c4-fc4f-40c9-8ba1-43f64dd65411	Grčka	grcka	Sitonija	Metamorfosis	t	9
d733552e-8f8f-462b-a326-adc6bbaf7fe8	Grčka	grcka	Kasandra	Hanioti	t	10
4630535d-6d15-4d6f-bf64-2bb873fb4f70	Grčka	grcka	Kasandra	Pefkohori	t	11
03ca584e-d562-4050-9e07-dc3bea87a1ba	Grčka	grcka	Kasandra	Polihrono	t	12
c07f8a3a-614c-43ef-941d-8871a08f4506	Grčka	grcka	Kasandra	Kalitea	t	13
2cd590ef-e475-4480-b924-157db50ca00a	Grčka	grcka	Kasandra	Afitos	t	14
a15be6b4-e91f-4661-b590-89dc5a370075	Grčka	grcka	Kasandra	Siviri	t	15
9fbde431-7bf1-4016-8a4e-2dd497b50766	Grčka	grcka	Olimpijska regija	Paralija	t	16
e43d1223-4ec8-4d27-8662-919d8560ce88	Hrvatska	hrvatska	Zagreb	Zagreb	t	0
007e4c98-9f78-45f4-9528-18d38bb43a7d	Hrvatska	hrvatska	Karlovac	Karlovac	t	1
0dfd4d92-6de6-49c2-8625-e14bc64e22d1	Hrvatska	hrvatska	Rijeka i Opatija	Rijeka	t	2
a4058f33-b434-4604-bea3-519383ae3a02	Hrvatska	hrvatska	Rijeka i Opatija	Opatija	t	3
ffa4dd3c-7e66-44e8-a637-862b580200a0	Hrvatska	hrvatska	Istra	Novigrad	t	4
e308316d-6887-4383-b017-f009ee6f85e3	Hrvatska	hrvatska	Istra	Umag	t	5
e37502eb-1c64-405e-8279-d114068fe411	Hrvatska	hrvatska	Istra	Poreč	t	6
c5ba765a-8cc9-423e-a6f0-0d55aeabe9eb	Hrvatska	hrvatska	Istra	Rovinj	t	7
11b0a304-bc88-4742-9b62-12b48f23f6d8	Hrvatska	hrvatska	Istra	Vrsar	t	8
897ae66a-b331-46d6-baa9-0c7147365c72	Hrvatska	hrvatska	Istra	Pula	t	9
347eec2f-b6ae-4f21-ad85-066293065443	Hrvatska	hrvatska	Istra	Medulin	t	10
2baa8d81-f30d-4c31-bb85-c1b10cd75ea8	Hrvatska	hrvatska	Split i Zadar	Split	t	11
aa4d03a1-e190-4009-b47a-a701b597a716	Hrvatska	hrvatska	Split i Zadar	Zadar	t	12
7a71e5df-c312-4198-95f4-62be7f434b7b	Makedonija	makedonija	Skoplje	Skoplje	t	0
68185c74-767f-4a0f-b9e8-ee943ff7b780	Makedonija	makedonija	Ohrid	Ohrid	t	1
1021e12d-bb70-4092-ad68-c892c7e8d9c4	Italija	italija	Trst	Trst	t	0
63c7a4b8-5d48-42d4-a3d6-b116589a44a2	Slovenija	slovenija	Slovenija	Ljubljana	f	0
140e65b1-3a65-41ce-abaa-f658012b0e8d	Slovenija	slovenija	Slovenija	Maribor	f	1
2441eca6-6309-4add-b596-c94ac9e2c8f8	Slovenija	slovenija	Slovenija	Celje	f	2
e3398aef-ccdd-43d9-850e-e2a095164735	Slovenija	slovenija	Slovenija	Ptuj	f	3
6ddaaca3-838b-40bf-9099-413e99c09e5d	Slovenija	slovenija	Slovenija	Novo Mesto	f	4
0f78da7d-c0b5-4f69-97f7-6ee180c99fcd	Slovenija	slovenija	Slovenija	Brežice	f	5
574d2575-50ff-4699-8ad8-d5518cfc3e02	Slovenija	slovenija	Slovenija	Bled	f	6
a180daef-f479-4e67-82ef-4bf937b92273	Bosna i Hercegovina	bih	Sarajevo	Sarajevo	f	0
d0c235a0-8021-430a-b625-6b04bbdeff35	Bosna i Hercegovina	bih	Jahorina	Jahorina	f	1
429dc0cd-c2a9-4580-98a2-744f9c188a55	Srbija	srbija	Niš	Niš	t	2
b221a06e-533e-4890-907e-8be05eb83873	Grčka	grcka	Sitonija	Kalamici	t	17
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."profiles" ("id", "ime", "email", "boja", "uloga", "tim_id", "aktivan") FROM stdin;
22ecbb36-23fd-4d78-905d-fb8f0d2c89ca	Petar	petarsosic4@gmail.com	#d97706	admin	\N	t
56231ad7-e99a-4425-ae45-f87a82b2c07d	Mihajlo	mihajlo28122002@gmail.com	#2563eb	admin	\N	t
36a46b48-7ce9-4348-ac09-a3582b195816	Radovan	radovanseslija74@gmail.com	#2563eb	korisnik	3b13c1d7-f574-42d7-9d45-65365e9eb7c4	t
dc2f52bf-bd9b-4da2-a33c-15812bda15fe	Denis	office@dreamteamtravel.rs	#d97706	korisnik	3b13c1d7-f574-42d7-9d45-65365e9eb7c4	t
6d044b37-aa25-4954-b16e-b6abc1ae102e	Test1	test@gmail.com	#059669	korisnik	cfceff58-f132-4ee9-8e39-a44196d726f3	t
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."reservations" ("id", "ime", "telefon", "destinacija_id", "datum_polaska", "destinacija_povratka_id", "datum_povratka", "broj_putnika", "kreirao", "tim_id") FROM stdin;
aa6c8382-bb99-45f9-9c98-1c04508c8a66	petar	+381654828282	b221a06e-533e-4890-907e-8be05eb83873	2026-09-15	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-23	1	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca	\N
2298d80d-0f31-46e4-ab31-97633de86772	Goran	+381632229111	9749d9b7-466c-4f44-a5ee-3b5fbb86d15f	2026-09-15	de97c014-4065-4e50-9599-f198f979d2cb	2026-09-16	1	22ecbb36-23fd-4d78-905d-fb8f0d2c89ca	\N
5b835ab7-64b2-4b2e-9321-51a709b7901b	Jelena Kostic	+3816525711941	b221a06e-533e-4890-907e-8be05eb83873	2026-09-11	429dc0cd-c2a9-4580-98a2-744f9c188a55	2026-09-19	2	36a46b48-7ce9-4348-ac09-a3582b195816	3b13c1d7-f574-42d7-9d45-65365e9eb7c4
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."settings" ("id", "podrazumevana_destinacija_id") FROM stdin;
1	de97c014-4065-4e50-9599-f198f979d2cb
\.


--
-- Data for Name: timovi; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."timovi" ("id", "naziv") FROM stdin;
3b13c1d7-f574-42d7-9d45-65365e9eb7c4	Euro Dream
cfceff58-f132-4ee9-8e39-a44196d726f3	Testni tim
\.


--
-- Name: destinacije destinacije_kljuc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."destinacije"
    ADD CONSTRAINT "destinacije_kljuc" UNIQUE ("drzava_sifra", "regija", "grad");


--
-- Name: destinacije destinacije_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."destinacije"
    ADD CONSTRAINT "destinacije_pkey" PRIMARY KEY ("id");


--
-- Name: profiles profiles_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_email_unique" UNIQUE ("email");


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_pkey" PRIMARY KEY ("id");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: timovi timovi_naziv_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."timovi"
    ADD CONSTRAINT "timovi_naziv_unique" UNIQUE ("naziv");


--
-- Name: timovi timovi_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."timovi"
    ADD CONSTRAINT "timovi_pkey" PRIMARY KEY ("id");


--
-- Name: destinacije_aktivna_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "destinacije_aktivna_idx" ON "public"."destinacije" USING "btree" ("aktivna");


--
-- Name: destinacije_drzava_sifra_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "destinacije_drzava_sifra_idx" ON "public"."destinacije" USING "btree" ("drzava_sifra");


--
-- Name: profiles_tim_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "profiles_tim_id_idx" ON "public"."profiles" USING "btree" ("tim_id");


--
-- Name: reservations_datum_polaska_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reservations_datum_polaska_idx" ON "public"."reservations" USING "btree" ("datum_polaska");


--
-- Name: reservations_datum_povratka_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reservations_datum_povratka_idx" ON "public"."reservations" USING "btree" ("datum_povratka");


--
-- Name: reservations_tim_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "reservations_tim_id_idx" ON "public"."reservations" USING "btree" ("tim_id");


--
-- Name: profiles profiles_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_users_id_fk" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: profiles profiles_tim_id_timovi_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_tim_id_timovi_id_fk" FOREIGN KEY ("tim_id") REFERENCES "public"."timovi"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_destinacija_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_destinacija_id_destinacije_id_fk" FOREIGN KEY ("destinacija_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_destinacija_povratka_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_destinacija_povratka_id_destinacije_id_fk" FOREIGN KEY ("destinacija_povratka_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_kreirao_profiles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_kreirao_profiles_id_fk" FOREIGN KEY ("kreirao") REFERENCES "public"."profiles"("id") ON DELETE RESTRICT;


--
-- Name: reservations reservations_tim_id_timovi_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reservations"
    ADD CONSTRAINT "reservations_tim_id_timovi_id_fk" FOREIGN KEY ("tim_id") REFERENCES "public"."timovi"("id") ON DELETE RESTRICT;


--
-- Name: settings settings_podrazumevana_destinacija_id_destinacije_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_podrazumevana_destinacija_id_destinacije_id_fk" FOREIGN KEY ("podrazumevana_destinacija_id") REFERENCES "public"."destinacije"("id") ON DELETE RESTRICT;


--
-- Name: profiles admini_insert_profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_insert_profiles" ON "public"."profiles" FOR INSERT TO "authenticated" WITH CHECK ("public"."je_admin"());


--
-- Name: settings admini_insert_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_insert_settings" ON "public"."settings" FOR INSERT TO "authenticated" WITH CHECK ("public"."je_admin"());


--
-- Name: timovi admini_insert_timovi; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_insert_timovi" ON "public"."timovi" FOR INSERT TO "authenticated" WITH CHECK ("public"."je_admin"());


--
-- Name: profiles admini_update_profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_update_profiles" ON "public"."profiles" FOR UPDATE TO "authenticated" USING ("public"."je_admin"()) WITH CHECK ("public"."je_admin"());


--
-- Name: settings admini_update_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_update_settings" ON "public"."settings" FOR UPDATE TO "authenticated" USING ("public"."je_admin"()) WITH CHECK ("public"."je_admin"());


--
-- Name: timovi admini_update_timovi; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admini_update_timovi" ON "public"."timovi" FOR UPDATE TO "authenticated" USING ("public"."je_admin"()) WITH CHECK ("public"."je_admin"());


--
-- Name: destinacije clanovi_select_destinacije; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_destinacije" ON "public"."destinacije" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: settings clanovi_select_settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_settings" ON "public"."settings" FOR SELECT TO "authenticated" USING ("public"."je_clan"());


--
-- Name: timovi clanovi_select_timovi; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "clanovi_select_timovi" ON "public"."timovi" FOR SELECT TO "authenticated" USING (("public"."je_admin"() OR ("id" = "public"."moj_tim"())));


--
-- Name: destinacije; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."destinacije" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."reservations" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: reservations tim_delete_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tim_delete_reservations" ON "public"."reservations" FOR DELETE TO "authenticated" USING (("public"."je_admin"() OR ("tim_id" = "public"."moj_tim"())));


--
-- Name: reservations tim_insert_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tim_insert_reservations" ON "public"."reservations" FOR INSERT TO "authenticated" WITH CHECK (("public"."je_admin"() OR ("public"."je_clan"() AND ("kreirao" = ( SELECT "auth"."uid"() AS "uid")) AND ("tim_id" = "public"."moj_tim"()))));


--
-- Name: profiles tim_select_profiles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tim_select_profiles" ON "public"."profiles" FOR SELECT TO "authenticated" USING (("public"."je_admin"() OR ("id" = ( SELECT "auth"."uid"() AS "uid")) OR (("uloga" <> 'admin'::"text") AND ("tim_id" = "public"."moj_tim"()))));


--
-- Name: reservations tim_select_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tim_select_reservations" ON "public"."reservations" FOR SELECT TO "authenticated" USING (("public"."je_admin"() OR ("tim_id" = "public"."moj_tim"())));


--
-- Name: reservations tim_update_reservations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "tim_update_reservations" ON "public"."reservations" FOR UPDATE TO "authenticated" USING (("public"."je_admin"() OR ("tim_id" = "public"."moj_tim"()))) WITH CHECK (("public"."je_admin"() OR ("tim_id" = "public"."moj_tim"())));


--
-- Name: timovi; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."timovi" ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict wQDdFxaJSFqBTVNMC5A4Rw2subWhruzLa1j5oY63qWyTosCn6jyujU2LQqz09MV

